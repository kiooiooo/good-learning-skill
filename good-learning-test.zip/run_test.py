from pathlib import Path
import os,subprocess,json
root=Path('/workspace/work/good-learning-independent'); src=Path((root/'source_dir.txt').read_text()); repo=Path('/workspace/good-learning-skill')
env=os.environ.copy(); env.update(TEXMFHOME='/workspace/.good-learning-env/root/usr/share/texlive/texmf-dist',TEXMFVAR=str(root/'texmf-var'),TEXMFCONFIG=str(root/'texmf-config'),XDG_CACHE_HOME=str(root/'cache'),FONTCONFIG_FILE=str(root/'fonts.conf'))
(root/'fonts.conf').write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>/usr/share/fonts/truetype/noto</dir><dir>/usr/share/fonts/opentype/noto</dir><dir>/usr/share/fonts/truetype/dejavu</dir><dir>/workspace/.good-learning-env/fonts</dir><cachedir>'+str(root/'cache')+'</cachedir></fontconfig>')
results=[]
for layout,label in [('compact','紧凑排版型'),('loose','宽松排版型')]:
    tex=src/f'等价无穷小-{label}.tex'; pdf=src.parent/f'等价无穷小-{label}.pdf'
    for kind,cmd in [('render',['python3',str(repo/'scripts/render_study_pdf.py'),str(src/'今日课程.md'),str(tex),'--kind','day','--layout',layout,'--map-config',str(src/'导图.json')]),('compile',['python3',str(repo/'scripts/compile_study_pdf.py'),str(tex),str(pdf)])]:
        r=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (root/f'{layout}-{kind}.log').write_text(r.stdout)
        results.append(dict(layout=layout,step=kind,returncode=r.returncode,output=r.stdout));print(layout,kind,r.returncode,r.stdout[-2500:])
        if r.returncode:break
(root/'script-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
