from pathlib import Path
import fitz, re, json, subprocess, os
from PIL import Image,ImageOps,ImageDraw
root=Path('/workspace/work/good-learning-independent'); src=Path((root/'source_dir.txt').read_text()); results={}; texts=[]
for pdf in sorted(src.parent.glob('*.pdf')):
    doc=fitz.open(pdf); pages=[]; text=''
    for i,p in enumerate(doc):
        text+=p.get_text()
        pix=p.get_pixmap(matrix=fitz.Matrix(0.85,0.85),alpha=False)
        img=Image.frombytes('RGB',(pix.width,pix.height),pix.samples); img=ImageOps.expand(img,border=(8,25,8,8),fill='white'); ImageDraw.Draw(img).text((8,5),f'Page {i+1}',fill='black'); pages.append(img)
    w=max(p.width for p in pages); h=max(p.height for p in pages); grid=Image.new('RGB',(w*3,h*((len(pages)+2)//3)), '#cccccc')
    for i,p in enumerate(pages):grid.paste(p,((i%3)*w,(i//3)*h))
    layout='compact' if '紧凑' in pdf.name else 'loose'; grid.save(root/f'{layout}-pages.png');(root/f'{layout}-text.txt').write_text(text)
    normal=re.sub(r'\s+','',text); normal=normal.replace('（紧凑排版型）','').replace('（宽松排版型）',''); normal=re.sub(r'\d+$','',normal)
    results[layout]={'pages':len(doc),'bytes':pdf.stat().st_size,'replacement_characters':text.count('\ufffd'),'path':str(pdf)}
    texts.append(normal)
print(json.dumps(results,ensure_ascii=False,indent=2))
(root/'pdf-verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
# Match same-content generated bodies after normalizing the layout-specific question commands.
a=(src/'等价无穷小-紧凑排版型.tex').read_text(); b=(src/'等价无穷小-宽松排版型.tex').read_text()
a=a[a.index('\\chaptertitle{'):]; b=b[b.index('\\chaptertitle{'):]
b=re.sub(r'\\PracticeQuestion\{([^}]+)\}\{(.*?)\}\{\d+\}',r'\\CompactQuestion{\1}{\2}',b)
print('same_body_after_layout_normalization',a==b)
